/**
 * 
 */
/**
 * @author Jagatheshwaran N
 *
 */
module Java9_JLink_Demo_Module {
	requires java.base;
}