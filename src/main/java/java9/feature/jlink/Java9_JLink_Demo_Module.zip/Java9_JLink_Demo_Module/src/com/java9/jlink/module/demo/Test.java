package com.java9.jlink.module.demo;

public class Test {

	public static void main(String[] args) {
		System.out.println("Custom JRE using JLink is Successful");
	}
}
