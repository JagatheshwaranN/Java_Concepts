package com.java9.module.addition;

public class Addition {

	public int add(int num1, int num2) {
		int result = num1 + num2;
		System.out.println("Addition of " + num1 + " and " + num2 + " is " + result);
		return result;
	}
}
