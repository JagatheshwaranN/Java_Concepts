/**
 * @author Jagatheshwaran N
 *
 */
module Math_Module {

	exports com.java9.module.addition;
	exports com.java9.module.subtraction;
}