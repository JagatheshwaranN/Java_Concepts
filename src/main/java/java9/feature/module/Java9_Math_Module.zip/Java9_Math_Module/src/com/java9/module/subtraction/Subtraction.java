package com.java9.module.subtraction;

public class Subtraction {

	public int sub(int num1, int num2) {
		int result = num1 - num2;
		System.out.println("Subtraction of " + num1 + " and " + num2 + " is " + result);
		return result;
	}
}
