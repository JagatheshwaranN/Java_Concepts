package com.java9.module.calculator;

import com.java9.module.addition.Addition;
import com.java9.module.subtraction.Subtraction;


public class Calculator {

	public static void main(String[] args) {
		Addition addition = new Addition();
		addition.add(10, 20);
		Subtraction substraction = new Subtraction();
		substraction.sub(20, 10);
	}
}
