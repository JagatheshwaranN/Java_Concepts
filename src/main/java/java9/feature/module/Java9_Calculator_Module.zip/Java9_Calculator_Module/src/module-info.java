/**
 * @author Jagatheshwaran N
 *
 */
module Calculator_Module {

	requires Math_Module;
}